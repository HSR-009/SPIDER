"""Titiler error classes."""

import logging
from collections.abc import Callable

from fastapi import FastAPI
from rasterio.errors import RasterioError, RasterioIOError
from rio_tiler.errors import (
    InvalidAssetName,
    InvalidBandName,
    InvalidColorFormat,
    InvalidExpression,
    InvalidFormat,
    MissingAssets,
    MissingBands,
    RioTilerError,
    TileOutsideBounds,
)
from starlette import status
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)


class TilerError(Exception):
    """Base exception class."""


class TileNotFoundError(TilerError):
    """Tile not found error."""


class BadRequestError(TilerError):
    """Bad request error."""


DEFAULT_STATUS_CODES = {
    BadRequestError: status.HTTP_400_BAD_REQUEST,
    TileOutsideBounds: status.HTTP_404_NOT_FOUND,
    TileNotFoundError: status.HTTP_404_NOT_FOUND,
    RasterioIOError: status.HTTP_500_INTERNAL_SERVER_ERROR,
    MissingBands: status.HTTP_400_BAD_REQUEST,
    MissingAssets: status.HTTP_400_BAD_REQUEST,
    InvalidColorFormat: status.HTTP_400_BAD_REQUEST,
    InvalidAssetName: status.HTTP_404_NOT_FOUND,
    InvalidBandName: status.HTTP_404_NOT_FOUND,
    RasterioError: status.HTTP_500_INTERNAL_SERVER_ERROR,
    RioTilerError: status.HTTP_500_INTERNAL_SERVER_ERROR,
    Exception: status.HTTP_500_INTERNAL_SERVER_ERROR,
    InvalidExpression: status.HTTP_400_BAD_REQUEST,
    InvalidFormat: status.HTTP_400_BAD_REQUEST,
}


def exception_handler_factory(status_code: int, exc_class: type[Exception]) -> Callable:
    """
    Create a FastAPI exception handler from a status code.
    """

    def handler(request: Request, exc: Exception):
        if status_code == status.HTTP_204_NO_CONTENT:
            return Response(content=None, status_code=204)

        # Only log concrete >=500 errors; the catch-all Exception/500 is
        # already re-raised and logged by Starlette's ServerErrorMiddleware.
        if status_code >= 500 and exc_class is not Exception:
            logger.error(
                "Exception mapped to HTTP %s response",
                status_code,
                exc_info=exc,
            )

        return JSONResponse(content={"detail": str(exc)}, status_code=status_code)

    return handler


def add_exception_handlers(
    app: FastAPI, status_codes: dict[type[Exception], int]
) -> None:
    """
    Add exception handlers to the FastAPI app.
    """
    for exc, code in status_codes.items():
        app.add_exception_handler(exc, exception_handler_factory(code, exc))
