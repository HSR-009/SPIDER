# -*- coding: utf_8 -*-
"""Logger Config."""
from pathlib import Path

import njsscan.settings as config
from njsscan.logger import init_logger

import yaml


logger = init_logger(__name__)

VALID_SEVERITIES = {'INFO', 'WARNING', 'ERROR'}


def normalize_severity_overrides(raw):
    """Parse severity-overrides map; return {rule_id: SEVERITY}."""
    if not raw or not isinstance(raw, dict):
        return {}
    overrides = {}
    for rule_id, severity in raw.items():
        if rule_id is None or severity is None:
            continue
        rid = str(rule_id).strip()
        sev = str(severity).strip().upper()
        if not rid:
            continue
        if sev not in VALID_SEVERITIES:
            logger.warning(
                'Invalid severity `%s` for rule `%s` in '
                'severity-overrides. Use INFO, WARNING, or ERROR.',
                severity, rid)
            continue
        overrides[rid] = sev
    return overrides


def get_config(base_path, config_file):
    options = {
        'nodejs_extensions': config.NODEJS_FILE_EXTENSIONS.copy(),
        'template_extensions': config.TEMPLATE_FILE_EXTENSIONS.copy(),
        'ignore_filenames': config.IGNORE_FILENAMES.copy(),
        'ignore_extensions': config.IGNORE_EXTENSIONS.copy(),
        'ignore_paths': config.IGNORE_PATHS.copy(),
        'ignore_rules': set(),
        'severity_filter': config.SEVERITY_FILTER,
        'severity_overrides': {},
    }
    if config_file:
        cfile = Path(config_file)
    else:
        cfile = Path(base_path[0]) / config.NJSSCAN_CONFIG_FILE
    if cfile.is_file() and cfile.exists():
        extras = read_yaml(cfile)
        root = validate_config(extras, options)
        if not root:
            logger.warning('Invalid YAML, ignoring config from .njsscan')
            return options
        usr_njs_ext = root.get('nodejs-extensions')
        usr_tmpl_ext = root.get('template-extensions')
        usr_ignore_files = root.get('ignore-filenames')
        usr_igonre_paths = root.get('ignore-paths')
        usr_ignore_exts = root.get('ignore-extensions')
        usr_ignore_rules = root.get('ignore-rules')
        usr_severity_filter = root.get('severity-filter')
        usr_severity_overrides = normalize_severity_overrides(
            root.get('severity-overrides'))
        if usr_njs_ext:
            options['nodejs_extensions'].update(usr_njs_ext)
        if usr_tmpl_ext:
            options['template_extensions'].update(usr_tmpl_ext)
        if usr_ignore_files:
            options['ignore_filenames'].update(usr_ignore_files)
        if usr_igonre_paths:
            options['ignore_paths'].update(usr_igonre_paths)
        if usr_ignore_exts:
            options['ignore_extensions'].update(usr_ignore_exts)
        if usr_ignore_rules:
            options['ignore_rules'].update(usr_ignore_rules)
        if usr_severity_filter:
            options['severity_filter'] = usr_severity_filter
        if usr_severity_overrides:
            options['severity_overrides'] = usr_severity_overrides
    return options


def validate_config(extras, options):
    """Validate user supplied config file."""
    if not extras:
        return False
    if isinstance(extras, dict):
        root = extras
    else:
        root = extras[0]
    valid = True
    for key, value in root.items():
        opt_key = key.replace('-', '_')
        if opt_key not in options.keys():
            valid = False
            logger.warning('The config `%s` is not supported.', key)
            continue
        if opt_key == 'severity_overrides':
            if not isinstance(value, dict):
                valid = False
                logger.warning(
                    'The value `%s` for the config `%s` is invalid.'
                    ' Only a mapping of rule_id: severity is supported.',
                    value, key)
            continue
        if not isinstance(value, list):
            valid = False
            logger.warning('The value `%s` for the config `%s` is invalid.'
                           ' Only list of value(s) are supported.', value, key)
    if not valid:
        return False
    return root


def read_missing_controls():
    """Read missing controls yaml."""
    return read_yaml(config.MISSING_CONTROLS)


def read_yaml(file_obj, text=False):
    """Read Yaml."""
    try:
        if text:
            return yaml.safe_load(file_obj)
        return yaml.safe_load(file_obj.read_text('utf-8', 'ignore'))
    except yaml.YAMLError:
        logger.error('Failed to parse YAML')
    except Exception:
        logger.exception('Error parsing YAML')
    return None
