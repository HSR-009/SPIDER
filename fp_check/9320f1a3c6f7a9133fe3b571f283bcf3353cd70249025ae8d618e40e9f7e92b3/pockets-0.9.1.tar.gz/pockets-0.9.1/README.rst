Pockets full of useful Python tools!
====================================

*Let me check my pockets...*
----------------------------

The Pockets library pulls together many of the Python helper functions I've
found useful over the years.

If you've worked on a project that exports an API and accesses a data store,
you've probably seen some code that looks like this::

    # Receive a data type with underscores from some API
    data_type = 'user_preference'

    # Convert underscored data type to CamelCase to match the data model
    model_name = camel(data_type)

    # Resolve the model name into a model class
    model_class = resolve(model_name, modules=["webapp.model.admin",
                                               "webapp.model.user",
                                               "webapp.model.businesslogic"]

    # Instantiate the model class and do stuff with the instance...
    instance = model_class()


There's an impedance mismatch any time you work with two different frameworks;
especially when you want to update your back-end while maintaining legacy
compatibility with an external API.

Pockets is full of highly tested, well maintained functions that help bridge
the gap. Here are just a few examples...

.. rubric :: Easily get the right logger no matter where you are

::

    >>> from pockets.autolog import log
    >>> log.error("Always log from the correct module.Class!")
    mymodule.MyClass: Always log from the correct module.Class!

.. rubric :: Convert underscore_separated string to CamelCase

::

    >>> from pockets import camel
    >>> camel("xml_http_request", upper_segments=[1])
    'XmlHTTPRequest'

.. rubric :: Convert CamelCase string to underscore_separated

::

    >>> from pockets import uncamel
    >>> uncamel("XmlHTTPRequest")
    'xml_http_request'

.. rubric :: Resolve a string into an object

::

    >>> from pockets import resolve
    >>> resolve("calendar.TextCalendar")
    <class 'calendar.TextCalendar'>

.. rubric :: Peek ahead iterator

::

    >>> from pockets import iterpeek
    >>> p = iterpeek(["a", "b", "c", "d", "e"])
    >>> p.peek()
    'a'
    >>> p.next()
    'a'
    >>> p.peek(3)
    ['b', 'c', 'd']


Downloads and Docs
------------------

Full documentation is available on `Read the Docs
<http://pockets.readthedocs.org>`_.

Built packages are available on `PyPI <https://pypi.python.org/pypi/pockets>`_.

`Source code <https://github.com/RobRuana/pockets>`_ is available on `GitHub
<https://github.com/RobRuana/pockets>`_. Feel free to:

- `Create an issue <https://github.com/RobRuana/pockets/issues>`_ to request a
  feature or a report a bug.
- `Fork the repository <https://github.com/RobRuana/pockets/fork>`_ and make
  changes to the **master** branch for next release.
- Send a pull request and pester the maintainer until it's merged. Make sure
  to add yourself to `AUTHORS
  <https://github.com/RobRuana/pockets/blob/master/AUTHORS>`_ and update
  `CHANGES <https://github.com/RobRuana/pockets/blob/master/CHANGES>`_.


Build Status
------------

.. image:: https://travis-ci.org/RobRuana/pockets.svg
    :target: https://travis-ci.org/RobRuana/pockets
    :alt: Build Status


.. image:: https://coveralls.io/repos/RobRuana/pockets/badge.svg
    :target: https://coveralls.io/r/RobRuana/pockets
    :alt: Coverage Status


.. image:: https://readthedocs.org/projects/pockets/badge/?version=latest
    :target: https://readthedocs.org/projects/pockets/?badge=latest
    :alt: Documentation Status

